#include "functional_tests.hpp"

using namespace std;

int main(void){
    exponentialTest();
    logisticTest();
    complexTest();

}