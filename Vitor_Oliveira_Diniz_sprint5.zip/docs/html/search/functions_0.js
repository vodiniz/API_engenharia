var searchData=
[
  ['add_0',['add',['../classModel.html#a5518050921f78abc062b9d861c15db11',1,'Model::add(Flow *)=0'],['../classModel.html#abc3f2e274a4ede4eac9f5e5ce38011df',1,'Model::add(System *)=0'],['../classModel.html#a1c5a3a7b40625912449979bd8c00159f',1,'Model::add(Model *model)'],['../classModelImpl.html#aa01c228bf49f0b7f5d72e293ac18defb',1,'ModelImpl::add(System *)'],['../classModelImpl.html#a33b51e276ed5f79ce97906a9abab85f7',1,'ModelImpl::add(Flow *)'],['../classModelImpl.html#a6230c100c06004691bcbf34dd297ffdb',1,'ModelImpl::add(Model *)']]]
];
