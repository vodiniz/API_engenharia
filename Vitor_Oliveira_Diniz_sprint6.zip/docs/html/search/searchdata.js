var indexSectionsWithContent =
{
  0: "abcdefghlmnoprstuv~",
  1: "befhlms",
  2: "fhmsu",
  3: "abcdefghlmorsu~",
  4: "cfmnprstv",
  5: "fms"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs"
};

