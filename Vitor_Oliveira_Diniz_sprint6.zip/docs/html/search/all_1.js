var searchData=
[
  ['body_0',['body',['../classBody.html',1,'Body'],['../classBody.html#a7727b0d8c998bbc2942e4c802e31e2eb',1,'Body::Body()'],['../classBody.html#ad7fa496772479f2d3debe3c1ea0e8c1b',1,'Body::Body(const Body &amp;)']]]
];
